import { useState, useRef, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Upload, Info, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function ReconciliationsPage() {
  const [selectedAccount, setSelectedAccount] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [csrfToken, setCsrfToken] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  const uploadMutation = useMutation({
    mutationFn: async ({ file, accountId }: { file: File; accountId: string }) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("bankAccountId", accountId);
      
      const res = await fetch("/api/reconciliations/ofx", {
        method: "POST",
        headers: { "X-CSRF-Token": csrfToken },
        credentials: "include",
        body: formData,
      });
      if (!res.ok) throw new Error("Failed to process OFX file");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ 
        title: "Conciliação concluída!",
        description: `${data.transactionsCreated || 0} transações importadas`,
      });
      setSelectedFile(null);
      setSelectedAccount("");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    onError: (error: Error) => {
      toast({ 
        title: "Erro ao processar arquivo OFX", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (!selectedFile || !selectedAccount) {
      toast({
        title: "Dados incompletos",
        description: "Selecione uma conta e um arquivo OFX",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate({ file: selectedFile, accountId: selectedAccount });
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Conciliações (OFX)
            </h1>
            <p className="text-muted-foreground mt-1">
              Importe extratos bancários no formato OFX para conciliar suas transações
            </p>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Importar Arquivo OFX</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Arquivos OFX são fornecidos pelos bancos e contêm o extrato de transações. Arquivos com mais de um mês de movimentação podem gerar lentidão.
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="account">Conta bancária *</Label>
                <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                  <SelectTrigger id="account">
                    <SelectValue placeholder="Selecione uma conta" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="account-1">Conta Principal</SelectItem>
                    <SelectItem value="account-2">Conta Empresarial</SelectItem>
                    <SelectItem value="account-3">Poupança</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">Arquivo OFX *</Label>
                <div className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary transition-colors">
                  <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileChange}
                    accept=".ofx"
                    className="hidden"
                    id="file-upload"
                  />
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-3" />
                  <Button 
                    type="button"
                    variant="default" 
                    className="gap-2"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4" />
                    Escolher arquivo
                  </Button>
                  <p className="text-sm text-muted-foreground mt-3">
                    {selectedFile ? selectedFile.name : "Nenhum arquivo selecionado"}
                  </p>
                </div>
              </div>

              <div className="flex gap-3 justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSelectedFile(null);
                    setSelectedAccount("");
                    if (fileInputRef.current) {
                      fileInputRef.current.value = "";
                    }
                  }}
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleUpload}
                  disabled={uploadMutation.isPending || !selectedFile || !selectedAccount}
                >
                  {uploadMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    "Importar"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Como obter arquivo OFX?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-semibold">1. Acesse seu internet banking</h4>
                <p className="text-sm text-muted-foreground">
                  Entre na plataforma do seu banco (site ou app)
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">2. Encontre a opção de exportar extrato</h4>
                <p className="text-sm text-muted-foreground">
                  Geralmente está em "Extratos", "Exportar" ou "Download"
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">3. Escolha o formato OFX</h4>
                <p className="text-sm text-muted-foreground">
                  Selecione OFX como formato de exportação (alguns bancos chamam de "Money" ou "Quicken")
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">4. Faça o download</h4>
                <p className="text-sm text-muted-foreground">
                  Baixe o arquivo e importe aqui no sistema
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
