import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Building, User, Settings, Bell, Lock, Palette, Globe, Shield, Zap, Mail, Phone, MapPin, Activity, Sun, Moon, Monitor, Smartphone, Laptop, Tablet, X, Copy, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "next-themes";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PasswordInput } from "@/components/ui/password-input";
import { maskPhone, maskZipCode, fetchAddressFromCEP } from "@/lib/masks";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Organization {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  planType: string | null;
  createdAt: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  passwordChangedAt: string | null;
}

interface TwoFactorStatus {
  enabled: boolean;
  configured: boolean;
}

interface ActiveSession {
  sid: string;
  device: string;
  browser: string;
  os: string;
  ipAddress: string;
  lastActivity: string;
  current: boolean;
}

interface UserPreferences {
  emailNotifications: boolean;
  activityAlerts: boolean;
  themePreference: string;
  colorScheme: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { theme, setTheme } = useTheme();
  const [csrfToken, setCsrfToken] = useState("");
  const [orgFormData, setOrgFormData] = useState({
    name: "",
    email: "",
    phone: "",
    document: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  });
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    activityAlerts: true,
  });
  const [colorScheme, setColorScheme] = useState("purple");
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [is2FADialogOpen, setIs2FADialogOpen] = useState(false);
  const [isSessionsDialogOpen, setIsSessionsDialogOpen] = useState(false);
  const [passwordFormData, setPasswordFormData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [twoFactorToken, setTwoFactorToken] = useState("");
  const [disable2FAToken, setDisable2FAToken] = useState("");
  const [copied, setCopied] = useState(false);

  const handlePhoneChange = (value: string) => {
    setOrgFormData(prev => ({ ...prev, phone: maskPhone(value) }));
  };

  const handleZipCodeChange = async (value: string) => {
    const masked = maskZipCode(value);
    setOrgFormData(prev => ({ ...prev, zipCode: masked }));
    
    if (masked.replace(/\D/g, '').length === 8) {
      const addressData = await fetchAddressFromCEP(masked);
      if (addressData) {
        setOrgFormData(prev => ({
          ...prev,
          address: addressData.logradouro || prev.address,
          city: addressData.localidade || prev.city,
          state: addressData.uf || prev.state,
        }));
      }
    }
  };

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  const { data: organization, isLoading } = useQuery<Organization>({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const res = await fetch("/api/organizations/current", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch organization");
      return res.json();
    },
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const res = await fetch("/api/user", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch user");
      return res.json();
    },
  });

  const { data: twoFactorStatus, refetch: refetch2FAStatus } = useQuery<TwoFactorStatus>({
    queryKey: ["/api/user/2fa/status"],
    queryFn: async () => {
      const res = await fetch("/api/user/2fa/status", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch 2FA status");
      return res.json();
    },
  });

  const { data: activeSessions, refetch: refetchSessions } = useQuery<ActiveSession[]>({
    queryKey: ["/api/user/sessions"],
    queryFn: async () => {
      const res = await fetch("/api/user/sessions", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch sessions");
      return res.json();
    },
  });

  const { data: userPreferences } = useQuery<UserPreferences>({
    queryKey: ["/api/user/preferences"],
    queryFn: async () => {
      const res = await fetch("/api/user/preferences", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch preferences");
      return res.json();
    },
  });

  useEffect(() => {
    if (userPreferences) {
      setNotifications({
        emailNotifications: userPreferences.emailNotifications,
        activityAlerts: userPreferences.activityAlerts,
      });
      setColorScheme(userPreferences.colorScheme);
      if (userPreferences.themePreference) {
        setTheme(userPreferences.themePreference);
      }
    }
  }, [userPreferences]);

  // Apply color scheme to CSS variables
  useEffect(() => {
    const colorMap: Record<string, string> = {
      purple: '270 91% 65%',
      blue: '217 91% 60%',
      green: '142 76% 36%',
      orange: '25 95% 53%',
      pink: '330 81% 60%',
    };
    
    const hslColor = colorMap[colorScheme] || colorMap.purple;
    document.documentElement.style.setProperty('--primary', hslColor);
  }, [colorScheme]);

  const generate2FAMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/user/2fa/generate", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
      });
      if (!res.ok) throw new Error("Failed to generate 2FA");
      return res.json();
    },
    onSuccess: (data) => {
      setQrCodeUrl(data.qrCodeUrl);
      setIs2FADialogOpen(true);
    },
    onError: () => {
      toast({ title: "Erro ao gerar 2FA", variant: "destructive" });
    },
  });

  const verify2FAMutation = useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch("/api/user/2fa/verify", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
        body: JSON.stringify({ token }),
      });
      if (!res.ok) throw new Error("Token inválido");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "2FA ativado com sucesso!" });
      setIs2FADialogOpen(false);
      setTwoFactorToken("");
      refetch2FAStatus();
    },
    onError: () => {
      toast({ title: "Token inválido", variant: "destructive" });
    },
  });

  const disable2FAMutation = useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch("/api/user/2fa/disable", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
        body: JSON.stringify({ token }),
      });
      if (!res.ok) throw new Error("Token inválido");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "2FA desativado com sucesso!" });
      setDisable2FAToken("");
      refetch2FAStatus();
    },
    onError: () => {
      toast({ title: "Token inválido", variant: "destructive" });
    },
  });

  const revokeSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const res = await fetch(`/api/user/sessions/${sessionId}`, {
        method: "DELETE",
        credentials: "include",
        headers: { "x-csrf-token": csrfToken },
      });
      if (!res.ok) throw new Error("Failed to revoke session");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Sessão encerrada com sucesso!" });
      refetchSessions();
    },
    onError: () => {
      toast({ title: "Erro ao encerrar sessão", variant: "destructive" });
    },
  });

  useEffect(() => {
    if (organization) {
      setOrgFormData({
        name: organization.name,
        email: organization.email || "",
        phone: organization.phone || "",
        document: organization.document || "",
        address: organization.address || "",
        city: organization.city || "",
        state: organization.state || "",
        zipCode: organization.zipCode || "",
      });
    }
  }, [organization]);

  const updateOrganizationMutation = useMutation({
    mutationFn: async (data: typeof orgFormData) => {
      const res = await fetch("/api/organizations/current", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update organization");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations/current"] });
      toast({ title: "Organização atualizada com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao atualizar organização", variant: "destructive" });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: typeof passwordFormData) => {
      const res = await fetch("/api/user/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message);
      }
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Senha alterada com sucesso!" });
      setIsPasswordDialogOpen(false);
      setPasswordFormData({ currentPassword: "", newPassword: "", confirmPassword: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({ title: error.message || "Erro ao alterar senha", variant: "destructive" });
    },
  });

  const savePreferencesMutation = useMutation({
    mutationFn: async (preferences: Partial<UserPreferences>) => {
      const res = await fetch("/api/user/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken },
        body: JSON.stringify(preferences),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to save preferences");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/preferences"] });
      toast({ title: "Preferências salvas com sucesso!" });
    },
    onError: () => {
      toast({ title: "Erro ao salvar preferências", variant: "destructive" });
    },
  });

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordFormData.newPassword !== passwordFormData.confirmPassword) {
      toast({ title: "As senhas não coincidem", variant: "destructive" });
      return;
    }
    if (passwordFormData.newPassword.length < 6) {
      toast({ title: "A senha deve ter pelo menos 6 caracteres", variant: "destructive" });
      return;
    }
    changePasswordMutation.mutate(passwordFormData);
  };

  const handleOrgSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateOrganizationMutation.mutate(orgFormData);
  };

  const calculateDaysSince = (date: string | null): string => {
    if (!date) return "Nunca";
    const days = Math.floor((Date.now() - new Date(date).getTime()) / (1000 * 60 * 60 * 24));
    if (days === 0) return "Hoje";
    if (days === 1) return "Ontem";
    return `${days} dias atrás`;
  };

  const formatDate = (date: string): string => {
    return new Date(date).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getPlanName = (planType: string | null): string => {
    const plans: Record<string, string> = {
      personal: "Pessoal",
      business: "Empresarial",
      enterprise: "Corporativo",
    };
    return plans[planType || "personal"] || "Pessoal";
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-6 pb-8"
      >
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
              Configurações
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie suas preferências e configurações do sistema
            </p>
          </div>
          <Settings className="h-8 w-8 text-purple-500 animate-pulse" />
        </motion.div>

        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-3">
          <Card className="border-border/50 bg-gradient-to-br from-purple-500/10 to-purple-600/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Building className="h-4 w-4" />
                Organização
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{organization?.name || "N/A"}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Desde {organization?.createdAt ? new Date(organization.createdAt).toLocaleDateString("pt-BR") : "N/A"}
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-gradient-to-br from-purple-500/10 to-purple-600/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold flex items-center gap-2">
                Ativo
                <Badge variant="default" className="bg-purple-500">Premium</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Todos os recursos disponíveis
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-gradient-to-br from-purple-500/10 to-purple-600/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Plano Atual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{getPlanName(organization?.planType || null)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Renovação automática
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Tabs defaultValue="organization" className="space-y-6">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="organization" className="gap-2">
                <Building className="h-4 w-4" />
                Organização
              </TabsTrigger>
              <TabsTrigger value="account" className="gap-2">
                <User className="h-4 w-4" />
                Conta
              </TabsTrigger>
              <TabsTrigger value="preferences" className="gap-2">
                <Palette className="h-4 w-4" />
                Preferências
              </TabsTrigger>
            </TabsList>

          <TabsContent value="organization">
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Building className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle>Informações da Organização</CardTitle>
                    <CardDescription>
                      Atualize os dados cadastrais da sua empresa
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleOrgSubmit} className="space-y-6">
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="org-name" className="flex items-center gap-2">
                        <Building className="h-4 w-4 text-muted-foreground" />
                        Nome da Organização
                      </Label>
                      <Input
                        id="org-name"
                        value={orgFormData.name}
                        onChange={(e) => setOrgFormData({ ...orgFormData, name: e.target.value })}
                        placeholder="Nome da empresa"
                        required
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="org-email" className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        Email
                      </Label>
                      <Input
                        id="org-email"
                        type="email"
                        value={orgFormData.email}
                        onChange={(e) => setOrgFormData({ ...orgFormData, email: e.target.value })}
                        placeholder="contato@empresa.com"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="org-phone" className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        Telefone
                      </Label>
                      <Input
                        id="org-phone"
                        value={orgFormData.phone}
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        placeholder="(11) 98765-4321"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="org-document" className="flex items-center gap-2">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        CNPJ/CPF
                      </Label>
                      <Input
                        id="org-document"
                        value={orgFormData.document}
                        onChange={(e) => setOrgFormData({ ...orgFormData, document: e.target.value })}
                        placeholder="00.000.000/0000-00"
                      />
                    </div>

                    <Separator className="my-2" />

                    <div className="grid gap-2">
                      <Label htmlFor="org-zipcode" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        CEP
                      </Label>
                      <Input
                        id="org-zipcode"
                        value={orgFormData.zipCode}
                        onChange={(e) => handleZipCodeChange(e.target.value)}
                        placeholder="00000-000"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="org-address">Endereço</Label>
                      <Input
                        id="org-address"
                        value={orgFormData.address}
                        onChange={(e) => setOrgFormData({ ...orgFormData, address: e.target.value })}
                        placeholder="Rua, número"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="org-city">Cidade</Label>
                        <Input
                          id="org-city"
                          value={orgFormData.city}
                          onChange={(e) => setOrgFormData({ ...orgFormData, city: e.target.value })}
                          placeholder="Cidade"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="org-state">Estado</Label>
                        <Input
                          id="org-state"
                          value={orgFormData.state}
                          onChange={(e) => setOrgFormData({ ...orgFormData, state: e.target.value })}
                          placeholder="UF"
                          maxLength={2}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <Button type="button" variant="outline">
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateOrganizationMutation.isPending}
                      className="gap-2 shadow-lg shadow-primary/20"
                    >
                      {updateOrganizationMutation.isPending && (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      )}
                      Salvar Alterações
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <div className="space-y-6">
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <User className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Segurança da Conta</CardTitle>
                      <CardDescription>
                        Gerencie suas credenciais e autenticação
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Lock className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Senha</p>
                        <p className="text-sm text-muted-foreground">
                          Última alteração {calculateDaysSince(currentUser?.passwordChangedAt || null)}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" onClick={() => setIsPasswordDialogOpen(true)}>Alterar Senha</Button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Autenticação de Dois Fatores</p>
                        <p className="text-sm text-muted-foreground">
                          {twoFactorStatus?.enabled ? "Ativa" : "Adicione uma camada extra de segurança"}
                        </p>
                      </div>
                    </div>
                    {twoFactorStatus?.enabled ? (
                      <Badge variant="default" className="bg-green-500">Ativo</Badge>
                    ) : (
                      <Button variant="outline" onClick={() => generate2FAMutation.mutate()}>
                        Ativar
                      </Button>
                    )}
                  </div>

                  {twoFactorStatus?.enabled && (
                    <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <Shield className="h-5 w-5 text-yellow-600 mt-0.5" />
                          <div className="space-y-2">
                            <p className="font-medium text-sm">2FA ativo na sua conta</p>
                            <p className="text-sm text-muted-foreground">
                              Para desativar, insira o código do seu aplicativo autenticador
                            </p>
                            <div className="flex items-center gap-2 mt-3">
                              <InputOTP
                                maxLength={6}
                                value={disable2FAToken}
                                onChange={setDisable2FAToken}
                              >
                                <InputOTPGroup>
                                  <InputOTPSlot index={0} />
                                  <InputOTPSlot index={1} />
                                  <InputOTPSlot index={2} />
                                  <InputOTPSlot index={3} />
                                  <InputOTPSlot index={4} />
                                  <InputOTPSlot index={5} />
                                </InputOTPGroup>
                              </InputOTP>
                              <Button
                                variant="destructive"
                                size="sm"
                                disabled={disable2FAToken.length !== 6 || disable2FAMutation.isPending}
                                onClick={() => disable2FAMutation.mutate(disable2FAToken)}
                              >
                                {disable2FAMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                                Desativar 2FA
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Activity className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Sessões Ativas</p>
                        <p className="text-sm text-muted-foreground">
                          {activeSessions?.length || 0} {(activeSessions?.length || 0) === 1 ? 'dispositivo conectado' : 'dispositivos conectados'}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" onClick={() => setIsSessionsDialogOpen(true)}>Ver Sessões</Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <Bell className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Notificações</CardTitle>
                      <CardDescription>
                        Configure como você deseja ser notificado
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Email</p>
                        <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.emailNotifications}
                      onCheckedChange={(checked) => setNotifications({ ...notifications, emailNotifications: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Activity className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Atividades</p>
                        <p className="text-sm text-muted-foreground">Alertas sobre ações importantes</p>
                      </div>
                    </div>
                    <Switch 
                      checked={notifications.activityAlerts}
                      onCheckedChange={(checked) => setNotifications({ ...notifications, activityAlerts: checked })}
                    />
                  </div>
                  <div className="flex justify-end pt-4">
                    <Button 
                      onClick={() => savePreferencesMutation.mutate({ 
                        emailNotifications: notifications.emailNotifications,
                        activityAlerts: notifications.activityAlerts
                      })}
                      disabled={savePreferencesMutation.isPending}
                    >
                      {savePreferencesMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                      Salvar Preferências
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preferences">
            <div className="space-y-6">
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <Palette className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle>Aparência</CardTitle>
                      <CardDescription>
                        Personalize a interface do sistema
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium mb-2">Tema</p>
                      <p className="text-sm text-muted-foreground mb-4">Escolha entre claro, escuro ou automático</p>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <Button
                        variant={theme === "light" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ themePreference: "light" });
                        }}
                        className="flex flex-col items-center gap-2 h-auto py-4"
                      >
                        <Sun className="h-5 w-5" />
                        <span>Claro</span>
                      </Button>
                      <Button
                        variant={theme === "dark" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ themePreference: "dark" });
                        }}
                        className="flex flex-col items-center gap-2 h-auto py-4"
                      >
                        <Moon className="h-5 w-5" />
                        <span>Escuro</span>
                      </Button>
                      <Button
                        variant={theme === "system" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ themePreference: "system" });
                        }}
                        className="flex flex-col items-center gap-2 h-auto py-4"
                      >
                        <Monitor className="h-5 w-5" />
                        <span>Sistema</span>
                      </Button>
                    </div>
                  </div>

                  <Separator className="my-6" />

                  <div className="space-y-3">
                    <div>
                      <p className="font-medium mb-2">Cor do Sistema</p>
                      <p className="text-sm text-muted-foreground mb-4">Escolha a cor primária do sistema</p>
                    </div>
                    <div className="grid grid-cols-5 gap-3">
                      <Button
                        variant={colorScheme === "purple" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ colorScheme: "purple" });
                        }}
                        className="h-16 flex flex-col items-center justify-center gap-1"
                      >
                        <div className="w-6 h-6 rounded-full bg-purple-500"></div>
                        <span className="text-xs">Roxo</span>
                      </Button>
                      <Button
                        variant={colorScheme === "blue" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ colorScheme: "blue" });
                        }}
                        className="h-16 flex flex-col items-center justify-center gap-1"
                      >
                        <div className="w-6 h-6 rounded-full bg-blue-500"></div>
                        <span className="text-xs">Azul</span>
                      </Button>
                      <Button
                        variant={colorScheme === "green" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ colorScheme: "green" });
                        }}
                        className="h-16 flex flex-col items-center justify-center gap-1"
                      >
                        <div className="w-6 h-6 rounded-full bg-green-600"></div>
                        <span className="text-xs">Verde</span>
                      </Button>
                      <Button
                        variant={colorScheme === "orange" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ colorScheme: "orange" });
                        }}
                        className="h-16 flex flex-col items-center justify-center gap-1"
                      >
                        <div className="w-6 h-6 rounded-full bg-orange-500"></div>
                        <span className="text-xs">Laranja</span>
                      </Button>
                      <Button
                        variant={colorScheme === "pink" ? "default" : "outline"}
                        size="lg"
                        onClick={() => {
                          savePreferencesMutation.mutate({ colorScheme: "pink" });
                        }}
                        className="h-16 flex flex-col items-center justify-center gap-1"
                      >
                        <div className="w-6 h-6 rounded-full bg-purple-500"></div>
                        <span className="text-xs">Rosa</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
        </motion.div>

        <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Alterar Senha</DialogTitle>
              <DialogDescription>
                Digite sua senha atual e escolha uma nova senha segura
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Senha Atual</Label>
                <PasswordInput
                  id="current-password"
                  value={passwordFormData.currentPassword}
                  onChange={(e) => setPasswordFormData({ ...passwordFormData, currentPassword: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">Nova Senha</Label>
                <PasswordInput
                  id="new-password"
                  value={passwordFormData.newPassword}
                  onChange={(e) => setPasswordFormData({ ...passwordFormData, newPassword: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                <PasswordInput
                  id="confirm-password"
                  value={passwordFormData.confirmPassword}
                  onChange={(e) => setPasswordFormData({ ...passwordFormData, confirmPassword: e.target.value })}
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsPasswordDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={changePasswordMutation.isPending}>
                  {changePasswordMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  Alterar Senha
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={is2FADialogOpen} onOpenChange={setIs2FADialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Configurar Autenticação de Dois Fatores</DialogTitle>
              <DialogDescription>
                Escaneie o QR code abaixo com seu aplicativo autenticador
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {qrCodeUrl && (
                <div className="flex justify-center p-4 bg-white rounded-lg">
                  <img src={qrCodeUrl} alt="QR Code 2FA" className="w-48 h-48" />
                </div>
              )}
              
              <Alert>
                <AlertDescription className="text-sm">
                  Use aplicativos como Google Authenticator, Authy ou Microsoft Authenticator para escanear o código
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label>Digite o código de 6 dígitos</Label>
                <InputOTP
                  maxLength={6}
                  value={twoFactorToken}
                  onChange={setTwoFactorToken}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIs2FADialogOpen(false)}>
                Cancelar
              </Button>
              <Button
                type="button"
                disabled={twoFactorToken.length !== 6 || verify2FAMutation.isPending}
                onClick={() => verify2FAMutation.mutate(twoFactorToken)}
              >
                {verify2FAMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                Ativar 2FA
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isSessionsDialogOpen} onOpenChange={setIsSessionsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Sessões Ativas</DialogTitle>
              <DialogDescription>
                Gerencie os dispositivos conectados à sua conta
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {activeSessions && activeSessions.length > 0 ? (
                activeSessions.map((session) => (
                  <div
                    key={session.sid}
                    className={`flex items-start justify-between p-4 rounded-lg border ${
                      session.current ? 'bg-purple-500/10 border-purple-500/30' : 'bg-muted/50 border-border/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {session.device.toLowerCase().includes('mobile') || session.device.toLowerCase().includes('phone') ? (
                        <Smartphone className="h-5 w-5 text-muted-foreground mt-1" />
                      ) : session.device.toLowerCase().includes('tablet') ? (
                        <Tablet className="h-5 w-5 text-muted-foreground mt-1" />
                      ) : (
                        <Laptop className="h-5 w-5 text-muted-foreground mt-1" />
                      )}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{session.device}</p>
                          {session.current && (
                            <Badge variant="default" className="text-xs">Esta sessão</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{session.browser}</p>
                        <p className="text-sm text-muted-foreground">{session.os}</p>
                        <p className="text-sm text-muted-foreground">IP: {session.ipAddress}</p>
                        <p className="text-xs text-muted-foreground">
                          Última atividade: {formatDate(session.lastActivity)}
                        </p>
                      </div>
                    </div>
                    {!session.current && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => revokeSessionMutation.mutate(session.sid)}
                        disabled={revokeSessionMutation.isPending}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-8">Nenhuma sessão ativa</p>
              )}
            </div>
            <DialogFooter>
              <Button onClick={() => setIsSessionsDialogOpen(false)}>Fechar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </AppLayout>
  );
}
