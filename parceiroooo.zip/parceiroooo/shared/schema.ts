import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, boolean, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const roleEnum = pgEnum("role", ["OWNER", "ADMIN", "CUSTOMER"]);
export const personTypeEnum = pgEnum("person_type", ["PF", "PJ"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", [
  "active",
  "canceled",
  "incomplete",
  "incomplete_expired",
  "past_due",
  "trialing",
  "unpaid"
]);
export const invoiceStatusEnum = pgEnum("invoice_status", ["draft", "pending", "paid", "overdue", "canceled"]);
export const planTypeEnum = pgEnum("plan_type", ["personal", "business", "enterprise"]);
export const transactionTypeEnum = pgEnum("transaction_type", ["income", "expense"]);
export const reconciliationStatusEnum = pgEnum("reconciliation_status", ["pending", "matched", "unmatched"]);
export const notificationTypeEnum = pgEnum("notification_type", ["invoice_due", "payment_received", "low_balance", "subscription_expiring", "system"]);

// Organizations Table
export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  document: text("document"), // CNPJ/CPF
  personType: personTypeEnum("person_type").default("PF"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  logo: text("logo"),
  planType: planTypeEnum("plan_type").default("personal"),
  stripeCustomerId: text("stripe_customer_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Users Table (expandido)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  avatar: text("avatar"),
  role: roleEnum("role").default("CUSTOMER").notNull(),
  emailVerified: boolean("email_verified").default(false),
  verificationToken: text("verification_token"),
  resetToken: text("reset_token"),
  resetTokenExpiry: timestamp("reset_token_expiry"),
  twoFactorSecret: text("two_factor_secret"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  passwordChangedAt: timestamp("password_changed_at"),
  emailNotifications: boolean("email_notifications").default(true),
  activityAlerts: boolean("activity_alerts").default(true),
  themePreference: text("theme_preference").default("system"),
  colorScheme: text("color_scheme").default("purple"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("users_organization_idx").on(table.organizationId),
  emailIdx: index("users_email_idx").on(table.email),
}));

// Customers Table
export const customers = pgTable("customers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  document: text("document"), // CPF/CNPJ
  personType: personTypeEnum("person_type").default("PF"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("customers_organization_idx").on(table.organizationId),
  emailIdx: index("customers_email_idx").on(table.email),
}));

// Invoices Table
export const invoices = pgTable("invoices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  customerId: varchar("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  invoiceNumber: text("invoice_number").notNull().unique(),
  description: text("description"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: invoiceStatusEnum("status").default("draft").notNull(),
  dueDate: timestamp("due_date"),
  paidDate: timestamp("paid_date"),
  issueDate: timestamp("issue_date").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("invoices_organization_idx").on(table.organizationId),
  customerIdx: index("invoices_customer_idx").on(table.customerId),
  statusIdx: index("invoices_status_idx").on(table.status),
}));

// Subscriptions Table (Stripe)
export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  stripeSubscriptionId: text("stripe_subscription_id").unique(),
  stripeCustomerId: text("stripe_customer_id"),
  stripePriceId: text("stripe_price_id"),
  status: subscriptionStatusEnum("status").default("incomplete").notNull(),
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
  planType: planTypeEnum("plan_type").default("personal"),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Activity Logs Table
export const activities = pgTable("activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(), // "created_invoice", "updated_customer", etc
  entityType: text("entity_type"), // "invoice", "customer", etc
  entityId: text("entity_id"),
  details: text("details"), // JSON string with details
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Categories Table
export const categories = pgTable("categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: transactionTypeEnum("type").notNull(),
  color: text("color"),
  icon: text("icon"),
  description: text("description"),
  parentId: varchar("parent_id").references((): any => categories.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Bank Accounts Table
export const bankAccounts = pgTable("bank_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  bank: text("bank"),
  agency: text("agency"),
  accountNumber: text("account_number"),
  initialBalance: decimal("initial_balance", { precision: 10, scale: 2 }).default("0"),
  currentBalance: decimal("current_balance", { precision: 10, scale: 2 }).default("0"),
  type: text("type"), // "checking", "savings", "credit"
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Cost Centers Table
export const costCenters = pgTable("cost_centers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  code: text("code"),
  description: text("description"),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Tags Table
export const tags = pgTable("tags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  color: text("color"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Transactions Table
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  type: transactionTypeEnum("type").notNull(),
  categoryId: varchar("category_id").references(() => categories.id, { onDelete: "set null" }),
  bankAccountId: varchar("bank_account_id").references(() => bankAccounts.id, { onDelete: "set null" }),
  costCenterId: varchar("cost_center_id").references(() => costCenters.id, { onDelete: "set null" }),
  customerId: varchar("customer_id").references(() => customers.id, { onDelete: "set null" }),
  date: timestamp("date").notNull(),
  dueDate: timestamp("due_date"),
  paidDate: timestamp("paid_date"),
  isPaid: boolean("is_paid").default(false),
  isRecurring: boolean("is_recurring").default(false),
  notes: text("notes"),
  attachments: text("attachments"), // JSON array of document IDs
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("transactions_organization_idx").on(table.organizationId),
  dateIdx: index("transactions_date_idx").on(table.date),
  typeIdx: index("transactions_type_idx").on(table.type),
  categoryIdx: index("transactions_category_idx").on(table.categoryId),
  bankAccountIdx: index("transactions_bank_account_idx").on(table.bankAccountId),
}));

// Transaction Tags (Many-to-Many)
export const transactionTags = pgTable("transaction_tags", {
  transactionId: varchar("transaction_id").notNull().references(() => transactions.id, { onDelete: "cascade" }),
  tagId: varchar("tag_id").notNull().references(() => tags.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Documents Table
export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size"),
  mimeType: text("mime_type"),
  url: text("url").notNull(), // Storage URL
  entityType: text("entity_type"), // "transaction", "invoice", "customer"
  entityId: text("entity_id"),
  uploadedBy: varchar("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Reconciliations Table (OFX)
export const reconciliations = pgTable("reconciliations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  bankAccountId: varchar("bank_account_id").notNull().references(() => bankAccounts.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  uploadDate: timestamp("upload_date").defaultNow().notNull(),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  totalTransactions: integer("total_transactions"),
  matchedTransactions: integer("matched_transactions"),
  status: reconciliationStatusEnum("status").default("pending"),
  data: text("data"), // JSON with OFX data
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User Preferences Table
export const userPreferences = pgTable("user_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").default("light"),
  language: text("language").default("pt-BR"),
  notifications: boolean("notifications").default(true),
  emailNotifications: boolean("email_notifications").default(true),
  currency: text("currency").default("BRL"),
  dateFormat: text("date_format").default("DD/MM/YYYY"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// API Keys Table
export const apiKeys = pgTable("api_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  keyHash: text("key_hash").notNull().unique(),
  lastUsedAt: timestamp("last_used_at"),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true).notNull(),
  permissions: text("permissions"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("api_keys_organization_idx").on(table.organizationId),
  keyHashIdx: index("api_keys_hash_idx").on(table.keyHash),
}));

// Notifications Table
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }),
  type: notificationTypeEnum("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  entityType: text("entity_type"),
  entityId: text("entity_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("notifications_organization_idx").on(table.organizationId),
  userIdx: index("notifications_user_idx").on(table.userId),
  isReadIdx: index("notifications_is_read_idx").on(table.isRead),
}));

// Recurring Transactions Table
export const recurringTransactions = pgTable("recurring_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  type: transactionTypeEnum("type").notNull(),
  categoryId: varchar("category_id").references(() => categories.id, { onDelete: "set null" }),
  bankAccountId: varchar("bank_account_id").references(() => bankAccounts.id, { onDelete: "set null" }),
  costCenterId: varchar("cost_center_id").references(() => costCenters.id, { onDelete: "set null" }),
  frequency: text("frequency").notNull(), // daily, weekly, monthly, yearly
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  lastGeneratedDate: timestamp("last_generated_date"),
  isActive: boolean("is_active").default(true).notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  organizationIdx: index("recurring_transactions_organization_idx").on(table.organizationId),
  isActiveIdx: index("recurring_transactions_is_active_idx").on(table.isActive),
}));

// Zod Schemas
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  resetToken: true,
  resetTokenExpiry: true,
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Schema para criação de cliente via API (sem organizationId, é injetado pelo servidor)
export const createCustomerSchema = insertCustomerSchema.omit({
  organizationId: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Schema para criação de fatura via API (sem organizationId e invoiceNumber, são injetados pelo servidor)
export const createInvoiceSchema = insertInvoiceSchema.omit({
  organizationId: true,
  invoiceNumber: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createCategorySchema = insertCategorySchema.omit({
  organizationId: true,
});

export const insertBankAccountSchema = createInsertSchema(bankAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createBankAccountSchema = insertBankAccountSchema.omit({
  organizationId: true,
});

export const insertCostCenterSchema = createInsertSchema(costCenters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createCostCenterSchema = insertCostCenterSchema.omit({
  organizationId: true,
});

export const insertTagSchema = createInsertSchema(tags).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createTagSchema = insertTagSchema.omit({
  organizationId: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createTransactionSchema = insertTransactionSchema.omit({
  organizationId: true,
}).extend({
  date: z.preprocess(
    (val) => (val === "" || val === null || val === undefined) ? undefined : val,
    z.coerce.date().refine((date) => !isNaN(date.getTime()), {
      message: "Invalid date format"
    })
  ),
  dueDate: z.preprocess(
    (val) => (val === "" || val === null || val === undefined) ? undefined : val,
    z.union([
      z.undefined(),
      z.coerce.date().refine((date) => !isNaN(date.getTime()), {
        message: "Invalid date format"
      })
    ])
  ).optional(),
  paidDate: z.preprocess(
    (val) => (val === "" || val === null || val === undefined) ? undefined : val,
    z.union([
      z.undefined(),
      z.coerce.date().refine((date) => !isNaN(date.getTime()), {
        message: "Invalid date format"
      })
    ])
  ).optional(),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createDocumentSchema = insertDocumentSchema.omit({
  organizationId: true,
});

export const insertReconciliationSchema = createInsertSchema(reconciliations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const createReconciliationSchema = insertReconciliationSchema.omit({
  organizationId: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const createNotificationSchema = insertNotificationSchema.omit({
  organizationId: true,
});

export const insertRecurringTransactionSchema = createInsertSchema(recurringTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastGeneratedDate: true,
});

export const createRecurringTransactionSchema = insertRecurringTransactionSchema.omit({
  organizationId: true,
});

// Select Schemas
export const selectOrganizationSchema = createSelectSchema(organizations);
export const selectUserSchema = createSelectSchema(users);
export const selectCustomerSchema = createSelectSchema(customers);
export const selectInvoiceSchema = createSelectSchema(invoices);
export const selectSubscriptionSchema = createSelectSchema(subscriptions);
export const selectCategorySchema = createSelectSchema(categories);
export const selectBankAccountSchema = createSelectSchema(bankAccounts);
export const selectCostCenterSchema = createSelectSchema(costCenters);
export const selectTagSchema = createSelectSchema(tags);
export const selectTransactionSchema = createSelectSchema(transactions);
export const selectDocumentSchema = createSelectSchema(documents);
export const selectReconciliationSchema = createSelectSchema(reconciliations);
export const selectUserPreferencesSchema = createSelectSchema(userPreferences);
export const selectNotificationSchema = createSelectSchema(notifications);
export const selectRecurringTransactionSchema = createSelectSchema(recurringTransactions);

// Types
export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type BankAccount = typeof bankAccounts.$inferSelect;
export type InsertBankAccount = z.infer<typeof insertBankAccountSchema>;

export type CostCenter = typeof costCenters.$inferSelect;
export type InsertCostCenter = z.infer<typeof insertCostCenterSchema>;

export type Tag = typeof tags.$inferSelect;
export type InsertTag = z.infer<typeof insertTagSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type Reconciliation = typeof reconciliations.$inferSelect;
export type InsertReconciliation = z.infer<typeof insertReconciliationSchema>;

export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;

export type ApiKey = typeof apiKeys.$inferSelect;
export type InsertApiKey = typeof apiKeys.$inferInsert;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type RecurringTransaction = typeof recurringTransactions.$inferSelect;
export type InsertRecurringTransaction = z.infer<typeof insertRecurringTransactionSchema>;
