import Stripe from "stripe";

let stripeInstance: Stripe | null = null;

export function getStripe(): Stripe {
  if (!stripeInstance) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error("STRIPE_SECRET_KEY is not configured");
    }
    stripeInstance = new Stripe(apiKey, {
      apiVersion: "2024-11-20.acacia",
    });
  }
  return stripeInstance;
}

export interface PriceConfig {
  personal: {
    monthly: string;
    yearly: string;
  };
  business: {
    monthly: string;
    yearly: string;
  };
  enterprise: {
    monthly: string;
    yearly: string;
  };
}

export const PRICES: PriceConfig = {
  personal: {
    monthly: process.env.STRIPE_PRICE_PERSONAL_MONTHLY || "",
    yearly: process.env.STRIPE_PRICE_PERSONAL_YEARLY || "",
  },
  business: {
    monthly: process.env.STRIPE_PRICE_BUSINESS_MONTHLY || "",
    yearly: process.env.STRIPE_PRICE_BUSINESS_YEARLY || "",
  },
  enterprise: {
    monthly: process.env.STRIPE_PRICE_ENTERPRISE_MONTHLY || "",
    yearly: process.env.STRIPE_PRICE_ENTERPRISE_YEARLY || "",
  },
};

export async function createCheckoutSession(
  customerId: string | null,
  priceId: string,
  organizationId: string,
  successUrl: string,
  cancelUrl: string
): Promise<Stripe.Checkout.Session> {
  const stripe = getStripe();

  const session = await stripe.checkout.sessions.create({
    customer: customerId || undefined,
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      organizationId,
    },
  });

  return session;
}

export async function createBillingPortalSession(
  customerId: string,
  returnUrl: string
): Promise<Stripe.BillingPortal.Session> {
  const stripe = getStripe();

  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });

  return session;
}

export async function constructWebhookEvent(
  rawBody: Buffer,
  signature: string
): Promise<Stripe.Event> {
  const stripe = getStripe();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    throw new Error("STRIPE_WEBHOOK_SECRET is not configured");
  }

  return stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
}

export async function handleCheckoutSessionCompleted(
  session: Stripe.Checkout.Session,
  storage: any
): Promise<void> {
  const organizationId = session.metadata?.organizationId;
  if (!organizationId) {
    console.error("No organizationId in session metadata");
    return;
  }

  const subscription = session.subscription as string;
  const customerId = session.customer as string;

  const stripeSubscription = await getStripe().subscriptions.retrieve(
    subscription
  );

  const planType =
    stripeSubscription.items.data[0].price.lookup_key?.split("_")[0] ||
    "personal";

  await storage.createSubscription({
    organizationId,
    stripeSubscriptionId: subscription,
    stripeCustomerId: customerId,
    stripePriceId: stripeSubscription.items.data[0].price.id,
    status: stripeSubscription.status,
    currentPeriodStart: new Date((stripeSubscription as any).current_period_start * 1000),
    currentPeriodEnd: new Date((stripeSubscription as any).current_period_end * 1000),
    planType: planType as "personal" | "business" | "enterprise",
    amount: (stripeSubscription.items.data[0].price.unit_amount! / 100).toString(),
  });

  await storage.updateOrganization(organizationId, {
    stripeCustomerId: customerId,
    planType: planType as "personal" | "business" | "enterprise",
  });
}

export async function handleSubscriptionUpdated(
  subscription: Stripe.Subscription,
  storage: any
): Promise<void> {
  const existing = await storage.getSubscriptionByStripeId(subscription.id);

  if (!existing) {
    console.error("Subscription not found:", subscription.id);
    return;
  }

  await storage.updateSubscription(existing.id, {
    status: subscription.status,
    currentPeriodStart: new Date((subscription as any).current_period_start * 1000),
    currentPeriodEnd: new Date((subscription as any).current_period_end * 1000),
    cancelAtPeriodEnd: subscription.cancel_at_period_end,
  });
}

export async function handleSubscriptionDeleted(
  subscription: Stripe.Subscription,
  storage: any
): Promise<void> {
  const existing = await storage.getSubscriptionByStripeId(subscription.id);

  if (!existing) {
    console.error("Subscription not found:", subscription.id);
    return;
  }

  await storage.updateSubscription(existing.id, {
    status: "canceled",
  });

  await storage.updateOrganization(existing.organizationId, {
    planType: "personal",
  });
}
