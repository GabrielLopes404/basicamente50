import * as Sentry from "@sentry/node";

export function initSentry() {
  const sentryDsn = process.env.SENTRY_DSN;
  
  if (!sentryDsn) {
    console.warn('SENTRY_DSN not configured. Error tracking disabled.');
    return;
  }

  Sentry.init({
    dsn: sentryDsn,
    environment: process.env.NODE_ENV || 'development',
    
    // Performance Monitoring
    tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    
    // BeforeSend hook to sanitize sensitive data
    beforeSend(event, hint) {
      // Remove sensitive data from event
      if (event.request) {
        delete event.request.cookies;
        
        // Sanitize headers
        if (event.request.headers) {
          delete event.request.headers['authorization'];
          delete event.request.headers['cookie'];
          delete event.request.headers['x-api-key'];
        }
        
        // Sanitize query parameters
        if (event.request.query_string) {
          const url = new URL(`http://example.com?${event.request.query_string}`);
          url.searchParams.delete('token');
          url.searchParams.delete('api_key');
          url.searchParams.delete('secret');
          event.request.query_string = url.searchParams.toString();
        }
      }
      
      // Remove password fields from extra data
      if (event.extra) {
        delete event.extra.password;
        delete event.extra.newPassword;
        delete event.extra.currentPassword;
      }
      
      return event;
    },
    
    // Ignore certain errors
    ignoreErrors: [
      // Browser errors
      'ResizeObserver loop limit exceeded',
      'Non-Error promise rejection captured',
      
      // Network errors
      'NetworkError',
      'Failed to fetch',
      'Network request failed',
      
      // Known non-critical errors
      'AbortError',
    ],
  });

  console.log(`Sentry initialized for ${process.env.NODE_ENV} environment`);
}

export { Sentry };
