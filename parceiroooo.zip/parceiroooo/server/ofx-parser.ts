interface OFXTransaction {
  id: string;
  date: Date;
  amount: number;
  description: string;
  type: "DEBIT" | "CREDIT";
  memo?: string;
}

interface OFXData {
  accountId: string;
  bankId: string;
  startDate: Date;
  endDate: Date;
  balance: number;
  transactions: OFXTransaction[];
}

export async function parseOFX(fileContent: string): Promise<OFXData> {
  const lines = fileContent.split('\n').map(l => l.trim());
  
  const getValue = (tag: string): string => {
    const regex = new RegExp(`<${tag}>([^<]+)`);
    for (const line of lines) {
      const match = line.match(regex);
      if (match) return match[1];
    }
    return '';
  };

  const accountId = getValue('ACCTID');
  const bankId = getValue('BANKID');
  const balance = parseFloat(getValue('LEDGERBAL')?.replace(',', '.') || getValue('BALAMT')?.replace(',', '.') || '0');
  
  const parseDate = (dateStr: string): Date => {
    if (!dateStr || dateStr.length < 8) return new Date();
    const year = parseInt(dateStr.substring(0, 4));
    const month = parseInt(dateStr.substring(4, 6)) - 1;
    const day = parseInt(dateStr.substring(6, 8));
    return new Date(year, month, day);
  };

  const dtstart = getValue('DTSTART');
  const dtend = getValue('DTEND');
  const startDate = parseDate(dtstart);
  const endDate = parseDate(dtend);

  const transactions: OFXTransaction[] = [];
  let currentTx: any = {};
  let inTransaction = false;

  for (const line of lines) {
    if (line.includes('<STMTTRN>')) {
      inTransaction = true;
      currentTx = {};
    } else if (line.includes('</STMTTRN>')) {
      if (currentTx.FITID && currentTx.DTPOSTED && currentTx.TRNAMT) {
        const amount = Math.abs(parseFloat(currentTx.TRNAMT.replace(',', '.')));
        transactions.push({
          id: currentTx.FITID,
          date: parseDate(currentTx.DTPOSTED),
          amount,
          description: currentTx.MEMO || currentTx.NAME || 'Transação sem descrição',
          type: parseFloat(currentTx.TRNAMT) >= 0 ? 'CREDIT' : 'DEBIT',
          memo: currentTx.MEMO
        });
      }
      inTransaction = false;
    } else if (inTransaction) {
      const match = line.match(/<(\w+)>([^<]+)/);
      if (match) {
        currentTx[match[1]] = match[2];
      }
    }
  }

  return {
    accountId,
    bankId,
    startDate,
    endDate,
    balance,
    transactions
  };
}

export function matchTransactions(
  ofxTransactions: OFXTransaction[],
  existingTransactions: any[]
): {
  matched: Array<{ ofx: OFXTransaction; existing: any }>;
  unmatched: OFXTransaction[];
  suggestions: Array<{ ofx: OFXTransaction; possible: any[] }>;
} {
  const matched: Array<{ ofx: OFXTransaction; existing: any }> = [];
  const unmatched: OFXTransaction[] = [];
  const suggestions: Array<{ ofx: OFXTransaction; possible: any[] }> = [];

  for (const ofxTx of ofxTransactions) {
    const exactMatch = existingTransactions.find(
      (tx) =>
        Math.abs(parseFloat(tx.amount) - ofxTx.amount) < 0.01 &&
        new Date(tx.date).toDateString() === ofxTx.date.toDateString()
    );

    if (exactMatch) {
      matched.push({ ofx: ofxTx, existing: exactMatch });
      continue;
    }

    const possibleMatches = existingTransactions.filter((tx) => {
      const dateDiff = Math.abs(
        new Date(tx.date).getTime() - ofxTx.date.getTime()
      );
      const daysDiff = dateDiff / (1000 * 60 * 60 * 24);
      const amountMatch = Math.abs(parseFloat(tx.amount) - ofxTx.amount) < 0.01;
      
      return amountMatch && daysDiff <= 3;
    });

    if (possibleMatches.length > 0) {
      suggestions.push({ ofx: ofxTx, possible: possibleMatches });
    } else {
      unmatched.push(ofxTx);
    }
  }

  return { matched, unmatched, suggestions };
}
